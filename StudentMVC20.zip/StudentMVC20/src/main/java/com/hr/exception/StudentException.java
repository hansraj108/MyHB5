package com.hr.exception;

public class StudentException extends Exception{
	
	public StudentException() {
		// TODO Auto-generated constructor stub
	}

	public StudentException(String s) {
		super(s);
	}
}
