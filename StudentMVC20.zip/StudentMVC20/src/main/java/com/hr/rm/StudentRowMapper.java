package com.hr.rm;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import org.springframework.jdbc.core.RowMapper;

import com.hr.bean.Student;

public class StudentRowMapper implements RowMapper<Student>{

	@Override
	public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
		Student s = new Student();
		s.setId(rs.getInt("id"));
		s.setName(rs.getString("name"));
		s.setMobile(rs.getLong("mobile"));
		s.setDob(getStringDOB(rs.getDate("dob")));
		s.setCountry(rs.getString("country"));
		return s;
	}
	
	public static String getStringDOB (java.sql.Date sqdob) {
		java.util.Date udob=sqdob;
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		return sdf.format(udob);
	}
	
	

}
