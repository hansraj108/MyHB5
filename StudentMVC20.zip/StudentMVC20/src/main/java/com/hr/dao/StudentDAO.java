package com.hr.dao;

import java.text.ParseException;
import java.util.List;

import com.hr.bean.Student;

public interface StudentDAO {

	public void save(Student s) throws ParseException;

	public void update(Student s) throws ParseException;

	public void delete(Student s);

	public void deleteById(Integer id);

	public Student findById(Integer id);

	public List<Student> findAll();

	public List<Student> findByProrperty(String propName, Object propValue);

}
